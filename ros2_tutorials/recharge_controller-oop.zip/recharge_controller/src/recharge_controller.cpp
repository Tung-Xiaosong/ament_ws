#include "recharge_controller/recharge_controller.hpp"

namespace recharge_controller_ns
{
    RechargeController::RechargeController() : Node("recharge_controller")
    {
       // auto publisher = recharge_controller_node->
    }
    RechargeController::~RechargeController()
    {}

}
